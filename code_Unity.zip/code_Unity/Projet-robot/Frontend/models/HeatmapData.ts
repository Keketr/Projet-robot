export interface HeatmapData{
    x; number;
    y; number;
    density; number;
}