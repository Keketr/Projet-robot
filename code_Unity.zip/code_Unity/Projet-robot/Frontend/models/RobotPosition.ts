export interface RobotPosition{
    id; number;
    robotId; number;
    x; number;
    y; number;
    timestamp; Date;

}