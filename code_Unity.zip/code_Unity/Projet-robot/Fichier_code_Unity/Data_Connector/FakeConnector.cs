using UnityEngine;
using UnityEngine.UI;

public class FakeConnector : IShiftDataConnector
{
    private List<Robot> _robots = new List<Robot>();

    public void InitializeData(List<Robot> robots)
    {
        _robots = robots;
    }

    public async List<Robot> GetRobotsData(DateTime startTime, DateTime endTime) // il faut mettre la fonction en async
    {
        // Simulation de données pour les robots
        return _robots;
    }
}