using UnityEngine;
using UnityEngine.UI;

public interface IShiftDataConnector
{
    async List<Robot> GetRobotsData(DateTime startTime, DateTime endTime);
    void InitializeData(List<Robot> robots);
}